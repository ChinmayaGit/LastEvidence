enum Suspect {
  colonelMustard('Colonel Mustard'),
  professorPlum('Professor Plum'),
  reverendGreen('Reverend Green'),
  mrsPeacock('Mrs Peacock'),
  missScarlett('Miss Scarlett'),
  mrsWhite('Mrs White');

  final String name;
  const Suspect(this.name);
}



