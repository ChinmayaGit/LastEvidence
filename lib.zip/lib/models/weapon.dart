enum Weapon {
  dagger('Dagger'),
  candlestick('Candlestick'),
  revolver('Revolver'),
  rope('Rope'),
  leadPiping('Lead Piping'),
  spanner('Spanner');

  final String name;
  const Weapon(this.name);
}



